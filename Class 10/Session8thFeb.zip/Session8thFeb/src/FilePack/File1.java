package FilePack;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;
// Read some text from keyboard then store that data in a textual file.
public class File1 {

	public static void main(String[] args) throws FileNotFoundException, IOException {
		FileOutputStream fos = new FileOutputStream("C:\\FileData\\Demo.txt");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Some Text ");
		String str = sc.nextLine();
		
		byte arr[] = str.getBytes();  // it will convert a string into bits and bytes
		
		fos.write(arr); // data has been written into the file.
		
		fos.close();
		
		System.out.println("Data Written in a file successfully....");
	}
}
