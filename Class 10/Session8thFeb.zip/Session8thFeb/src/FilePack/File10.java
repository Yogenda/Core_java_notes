package FilePack;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;
// Delete a file
public class File10 {

	public static void main(String[] args) throws IOException {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter file Name to delete : ");
		String fname = scn.next();
		
		File  fileObj = new File("C:\\FileData\\" + fname);
		
		if(fileObj.exists()==true)
		{
			fileObj.delete();
			System.out.println("File Deleted");
		}
		else
		{
			System.out.println("File Not Found");
		}
	}
}
