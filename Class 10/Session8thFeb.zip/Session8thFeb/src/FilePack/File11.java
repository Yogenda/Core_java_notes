package FilePack;

import java.io.File;
import java.io.IOException;
//Show List of files and Folders from specified folder
public class File11 {

	public static void main(String[] args) throws IOException {
	
		File  fileObj = new File("C:\\FileData");
		
		String content[] =fileObj.list();
		int fcount=0, dcount=0;
		for(String str : content)
		{
			File temp = new File("C:\\FileData\\" + str);
			if(temp.isFile())
				fcount++;
			if(temp.isDirectory())
				dcount++;
			System.out.println(str);	
		}
		
		System.out.println("No of Files " + fcount);
		System.out.println("No of Folders " + dcount);
	}
}
