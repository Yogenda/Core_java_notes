package FilePack;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;
// Read some text from keyboard then store that data in a textual file.
public class File2 {

	public static void main(String[] args) throws FileNotFoundException, IOException {
		FileOutputStream fos = new FileOutputStream("C:\\FileData\\Demo.txt");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Some Text ");
		String str = sc.nextLine();
		
		for(int i=0;i<str.length();i++)
		{
			char ch = str.charAt(i);
			int n = (int)ch;
			//System.out.println(ch + "  " + n);
			fos.write(n); // data has been written into the file.
		}

		fos.close();
		
		System.out.println("Data Written in a file successfully....");
	}
}
