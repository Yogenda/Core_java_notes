package FilePack;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
// Read data from file and present it on Monitor.
public class File3 {

	public static void main(String[] args) throws FileNotFoundException, IOException {
		FileInputStream  fis = new FileInputStream("C:\\FileData\\FSD Session-1.txt");
		
		int ch = fis.read();
		
		while(ch!=-1)
		{
			System.out.print((char)ch);
			ch = fis.read();
		}
		fis.close();
	}

}
