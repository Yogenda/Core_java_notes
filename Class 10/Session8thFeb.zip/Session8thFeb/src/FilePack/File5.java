package FilePack;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
// Read some text from keyboard then store that data in a textual file
// using FileWriter Class
public class File5 {

	public static void main(String[] args) throws FileNotFoundException, IOException {
		FileWriter fw = new FileWriter("C:\\FileData\\Demo1.txt", true);
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Some Text ");
		String str = sc.nextLine();
		
		str = "\n" + str;
		//str = " " + str;
		
		fw.write(str);
		
		fw.close();
		
		System.out.println("Data Written in a file successfully....");
	}
}
