package FilePack;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
// Store Some Books Info into a Books.txt file
public class File6 {

	public static void main(String[] args) throws FileNotFoundException, IOException {
		FileWriter fwBooks = new FileWriter("C:\\FileData\\Books.txt", true);
		Scanner sc = new Scanner(System.in);

		String ch = "";
		
		do
		{
			System.out.println("Book Name ");
			String bname = sc.next();
			
			System.out.println("Book Price ");
			float price = sc.nextFloat();
			
			System.out.println("Author ");
			String author = sc.next();
			
			String result =  bname + "\t"  + price + "\t" + author + "\n";
			
			fwBooks.write(result);
			
			System.out.println("1 More Book to Add(yes/no) ");
			ch=sc.next();
		}
		while(ch.equalsIgnoreCase("Yes"));
		fwBooks.close();
		System.out.println("Book Details are Stored in a file successfully....");
	}
}
