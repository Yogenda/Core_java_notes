package FilePack;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
// Read data from file and present it on Monitor using FileReader.
public class File7 {

	public static void main(String[] args) throws FileNotFoundException, IOException {
		FileReader  fr = new FileReader("C:\\FileData\\Books.txt");
		BufferedReader br = new BufferedReader(fr);
	//BufferedReader br = new BufferedReader(new FileReader("C:\\FileData\\FSD Session-1.txt"));
	
			String str = br.readLine();
			
			while(str!=null)
			{
				System.out.println(str);
				str = br.readLine();
			}
			
			fr.close();
			br.close();
			
	}

}
