package FilePack;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class File8 {

	public static void main(String[] args) throws IOException {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter File Name : ");
		String fname = scn.next();
		
		File  fileObj = new File("C:\\FileData\\" + fname);
		
		if(fileObj.exists()==true)
			System.out.println("File ALready exist");
		else
		{
			fileObj.createNewFile();
			System.out.println("File Created....");
		}
	}
}
