package FilePack;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;
// Folder Creation
public class File9 {

	public static void main(String[] args) throws IOException {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter Folder Name : ");
		String fname = scn.next();
		
		File  fileObj = new File("C:\\FileData\\" + fname);
		
		if(fileObj.exists()==true)
			System.out.println("Folder ALready exist");
		else
		{
			fileObj.mkdir();
			System.out.println("Folder Created....");
		}
	}
}
