package ListCollectionPack;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ListEx1 {

	public static void main(String[] args) {
		List<String>  lstStr = new ArrayList<String>();
		lstStr.add("Satya");
		lstStr.add("Sarala");
		lstStr.add("Satish");
		lstStr.add("Somesh");
		lstStr.add("Satya");
		lstStr.add("Suresh");
		
		System.out.println(lstStr);
		// Traversing by using foreach loop
		for(String str : lstStr)
		{
			System.out.println(str);
		}
		
		System.out.println("---------------------");
		
		Iterator  itr =  lstStr.iterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
	//	lstStr.add("Murali");
		
	//	System.out.println(lstStr);
	}

}
