package ListCollectionPack;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
// adding values to the list dynamically
public class ListEx3 {

	public static void main(String[] args) {
		List<String>  lstStr = new ArrayList<String>();
		Scanner sc = new Scanner(System.in);

		while(true)
		{
			System.out.println("Enter a string value(stop word is use for stop)");
			String st = sc.next();
			
			if(st.equalsIgnoreCase("stop"))
				break;
			lstStr.add(st);
		}
		
		
		
		System.out.println(lstStr);
		// Traversing by using foreach loop
		for(String str : lstStr)
		{
			System.out.println(str);
		}
		
		System.out.println("---------------------");
		
		Iterator  itr =  lstStr.iterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		
	}

}
