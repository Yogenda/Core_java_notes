package ListCollectionPack;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
// searching an element
public class ListEx4 {

	public static void main(String[] args) {
		List<String>  lstStr = new ArrayList<String>();
		lstStr.add("Satya");
		lstStr.add("Sarala");
		lstStr.add("Satish");
		lstStr.add("Somesh");
		lstStr.add("Satya");
		lstStr.add("Suresh");
		
		System.out.println(lstStr);
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a string to search ");
		String str = sc.next();
		
		if(lstStr.contains(str))
			System.out.println("Value is Existed");
		else
			System.out.println("Value is not existed");
	}

}
