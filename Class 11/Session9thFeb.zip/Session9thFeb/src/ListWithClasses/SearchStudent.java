package ListWithClasses;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
// student searching based on  rollno
public class SearchStudent {

	public static void main(String[] args) {
		List<Student> lstStd = new ArrayList<Student>();
		
		Student std = new Student(101, "Lokesh", "Java", 12000.00f);
		lstStd.add(std);
		std = new Student(102, "Mahesh", "Java", 12000.00f);
		lstStd.add(std);
		std = new Student(103, "Ramesh", "Java", 12000.00f);
		lstStd.add(std);
		std = new Student(104, "Suresh", "Java", 12000.00f);
		lstStd.add(std);
		std = new Student(105, "Naresh", "Java", 12000.00f);
		lstStd.add(std);
		
		System.out.println(lstStd);
		System.out.println("-----------");
		
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Roll Number ");
		int rno = sc.nextInt();
		
		
		boolean chk = false;
		for(Student st : lstStd)
		{
			if(st.getRollno()==rno)
			{
				System.out.println(st.getRollno() + "\t" + st.getSname() + "\t" + st.getCourse() + "\t" + st.getFees());
				chk = true;
				break;
			}
		}
		
		if(chk==false)
			System.out.println("Student Not Found");
	}
}
