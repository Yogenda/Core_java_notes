package ListWithClasses;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class StdDynamicMain {

	public static void main(String[] args) {
		List<Student> lstStd = new ArrayList<Student>();
		
		Student std = null;
		Scanner sc = new Scanner(System.in);
		
		while(true)
		{
			System.out.println("Roll Number ");
			int rno = sc.nextInt();
			
			System.out.println("Student Name ");
			String sname = sc.next();
			
			System.out.println("Course ");
			String course = sc.next();
			
			System.out.println("Course Fees ");
			float fees = sc.nextFloat();
			
			std = new Student(rno, sname, course, fees);
			lstStd.add(std);
			
			System.out.println("1 More Student(Yes/No)");
			String ch = sc.next();
			
			if(ch.equalsIgnoreCase("no"))
				break;
		}
		
		for(Student st : lstStd)
		{
			System.out.println(st.getRollno() + "\t" + st.getSname() + "\t" + st.getCourse() + "\t" + st.getFees());
		}
		System.out.println("-----------");
		Iterator itr = lstStd.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
	}

}
