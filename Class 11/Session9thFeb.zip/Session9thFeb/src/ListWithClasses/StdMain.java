package ListWithClasses;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class StdMain {

	public static void main(String[] args) {
		List<Student> lstStd = new ArrayList<Student>();
		
		Student std = new Student(101, "Lokesh", "Java", 12000.00f);
		lstStd.add(std);
		std = new Student(102, "Mahesh", "Java", 12000.00f);
		lstStd.add(std);
		std = new Student(103, "Ramesh", "Java", 12000.00f);
		lstStd.add(std);
		std = new Student(104, "Suresh", "Java", 12000.00f);
		lstStd.add(std);
		std = new Student(105, "Naresh", "Java", 12000.00f);
		lstStd.add(std);
		
		System.out.println(lstStd);
		System.out.println("-----------");
		for(Student st : lstStd)
		{
			System.out.println(st.getRollno() + "\t" + st.getSname() + "\t" + st.getCourse() + "\t" + st.getFees());
		}
		System.out.println("-----------");
		Iterator itr = lstStd.iterator();
		while(itr.hasNext())
		{
			//Student st = (Student)itr.next();
			//System.out.println(st.getRollno() + "\t" + st.getSname() + "\t" + st.getCourse() + "\t" + st.getFees());
			System.out.println(itr.next());
		}
	}

}
