package MapPack.Assignment;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Policy {

	Map<Integer, String>  policy = new TreeMap<Integer, String>();
	
	public void addPolicyDetails(int pid, String pname)
	{
		policy.put(pid, pname);
	}
	
	public  Map<Integer, String>  ViewAllPolicies()
	{
		return policy;
	}
	
	public List<Integer>  searchBasedOnPolicyType(String search)
	{
		List<Integer>  pids = new ArrayList<Integer>();
		
		for(Map.Entry<Integer, String> obj : policy.entrySet())
		{
			int  key = obj.getKey();
			String value = obj.getValue();
			
			if(value.contains(search))
				pids.add(key);
		}
		
		return pids;
	}
}
