package MapPack.Assignment;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class PolicyMain {

	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);
		Policy pcy = new Policy();
		InputStreamReader isr = new InputStreamReader(System.in); // keyboard
		BufferedReader br = new BufferedReader(isr);
		while(true)
		{
			System.out.println("1. Add policy\n2. View All Policies\n3. Search Policy\n4. Exit");
			System.out.println("Pick Option");
			int ch = sc.nextInt();
			
			switch(ch)
			{
			case 1:
				System.out.println("Enter policy id");
				int pid = sc.nextInt();
				System.out.println("Enter Policy name ");
				String pname = br.readLine();
				
				pcy.addPolicyDetails(pid, pname);
				System.out.println("Added Policy");
				break;
			case 2:
				Map<Integer,String>  allpolicies = pcy.ViewAllPolicies();
				for(Map.Entry<Integer, String> obj : allpolicies.entrySet())
				{
					System.out.println(obj.getKey() + "\t" + obj.getValue());
				}
				break;
			case 3:
				System.out.println("Enter Type of Policy ");
				String str = br.readLine();
				List<Integer>  pidinfo = pcy.searchBasedOnPolicyType(str);
				for(int n : pidinfo)
					System.out.println(n);
				break;
			case 4:
				System.out.println("Thanks for Using App");
				System.exit(0);
			}
		}

	}

}
