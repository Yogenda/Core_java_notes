package MapPack;

import java.util.Map;
import java.util.TreeMap;

public class MapEx3 {

	public static void main(String[] args) {
		Map<Integer, String> stdMap  = new TreeMap<Integer,String>();
		
		stdMap.put(1005, "Paramesh");
		stdMap.put(1001, "Ramesh");
		stdMap.put(1003, "Suresh");
		stdMap.put(1002, "Mahesh");
		stdMap.put(1004, "Lokesh");
		
		
		System.out.println(stdMap);
	}

}
