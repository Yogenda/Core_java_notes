package MapPack;


import java.util.HashMap;
import java.util.Map;

public class MapEx4 {
// Traversing Key-Value
	public static void main(String[] args) {
		Map<Integer, String> stdMap  = new HashMap<Integer,String>();
		
		stdMap.put(1005, "Paramesh");
		stdMap.put(1001, "Ramesh");
		stdMap.put(1003, "Suresh");
		stdMap.put(1002, "Mahesh");
		stdMap.put(1004, "Lokesh");
		
		System.out.println(stdMap);
		System.out.println("---------------------");
		for(Map.Entry<Integer,String>  obj : stdMap.entrySet())
		{
			System.out.println(obj.getKey() + "\t" + obj.getValue());
		}
	}
}
