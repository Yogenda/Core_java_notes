package MapPack;


import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class MapEx6 {
// Delete a key 
	public static void main(String[] args) {
		Map<Integer, String> stdMap  = new HashMap<Integer,String>();
		
		stdMap.put(1005, "Paramesh");
		stdMap.put(1001, "Ramesh");
		stdMap.put(1003, "Suresh");
		stdMap.put(1002, "Mahesh");
		stdMap.put(1004, "Lokesh");
		
		System.out.println(stdMap);
		System.out.println("---------------------");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a key to delete");
		int k = sc.nextInt();
		
		if(stdMap.containsKey(k))
		{
			System.out.println("Value is " + stdMap.get(k));
			stdMap.remove(k);
			System.out.println("Map After Delete : " +  stdMap);
		}
		else
			System.out.println("Key not present");
	}
}
