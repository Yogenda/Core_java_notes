package MapPack;


import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class MapEx7 {
// Modify value based on key
	public static void main(String[] args) {
		Map<Integer, String> stdMap  = new HashMap<Integer,String>();
		
		stdMap.put(1005, "Paramesh");
		stdMap.put(1001, "Ramesh");
		stdMap.put(1003, "Suresh");
		stdMap.put(1002, "Mahesh");
		stdMap.put(1004, "Lokesh");
		
		System.out.println(stdMap);
		System.out.println("---------------------");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a key to modify value");
		int k = sc.nextInt();
		
		if(stdMap.containsKey(k))
		{
			System.out.println("Present Value is : " + stdMap.get(k));
			System.out.println("Enter New Value to Modify : ");
			String nval = sc.next();
			stdMap.replace(k, nval);
			System.out.println("Map After Modify :\n" +  stdMap);
		}
		else
			System.out.println("Key not present");
	}
}
