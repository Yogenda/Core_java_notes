package SetPack;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class SetEx2 {

	public static void main(String[] args) {
		Set<String>  setStr = new LinkedHashSet<String>();
		setStr.add("Murali");
		setStr.add("Abhiram");
		setStr.add("Kiran");
		setStr.add("Satyam");
		setStr.add("Zaheer");
		setStr.add("Abhiram");
		setStr.add(null);  // one null value will be allowed.
		
		System.out.println(setStr);
	
	}

}
