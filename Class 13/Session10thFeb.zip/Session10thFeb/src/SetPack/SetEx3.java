package SetPack;

import java.util.Set;
import java.util.TreeSet;

public class SetEx3 {

	public static void main(String[] args) {
		Set<String>  setStr = new TreeSet<String>();
		setStr.add("Murali");
		setStr.add("Abhiram");
		setStr.add("Kiran");
		setStr.add("Satyam");
		setStr.add("Zaheer");
		setStr.add("Abhiram");
		//Treeset will not allow null values.
		
		System.out.println(setStr);
	
	}

}
