package SortingPack;

import java.util.Arrays;
import java.util.Collections;

public class ArraySort {

	public static void main(String[] args) {
		
		int x[]  = {10,-9,3,1,8};
		
		System.out.println("Actual Values ");
		for(int i=0;i<x.length;i++)
		{
			System.out.print(x[i] + "\t");
		}
		
		Arrays.sort(x);
		
		System.out.println("\nSorted Values in Asending Order ");
		for(int i=0;i<x.length;i++)
		{
			System.out.print(x[i] + "\t");
		}
		
		System.out.println("\nSorted Values in Desending Order ");
		for(int i=x.length-1;i>=0;i--)
		{
			System.out.print(x[i] + "\t");
		}

	}

}
