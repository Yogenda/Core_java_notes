package SortingPack;

import java.util.Comparator;

public class SortingBasedOnFees implements Comparator<Student2> {
	@Override
	public int compare(Student2 s1, Student2 s2) {
		// TODO Auto-generated method stub
		int res = Integer.compare((int)s1.getFees(), (int)s2.getFees());
		return res;
	}
}
