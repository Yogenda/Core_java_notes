package SortingPack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class StdSort {

	public static void main(String[] args) {
		List<Student> lstStd = new ArrayList<Student>();
		
		Student std = new Student(103, "Lokesh", "Java", 12000.00f);
		lstStd.add(std);
		std = new Student(102, "Mahesh", "Java", 12000.00f);
		lstStd.add(std);
		std = new Student(101, "Ramesh", "Java", 12000.00f);
		lstStd.add(std);
		std = new Student(105, "Suresh", "Java", 12000.00f);
		lstStd.add(std);
		std = new Student(104, "Naresh", "Java", 12000.00f);
		lstStd.add(std);
		
		
		System.out.println("Actual Data");
		for(Student st : lstStd)
		{
			System.out.println(st.getRollno() + "\t" + st.getSname() + "\t" + st.getCourse() + "\t" + st.getFees());
		}
		
		Collections.sort(lstStd);
		
		System.out.println("Sorted Data");
		for(Student st : lstStd)
		{
			System.out.println(st.getRollno() + "\t" + st.getSname() + "\t" + st.getCourse() + "\t" + st.getFees());
		}
		
		
		Collections.sort(lstStd, Collections.reverseOrder());
		
		System.out.println("Sorted Data in Desending Order");
		for(Student st : lstStd)
		{
			System.out.println(st.getRollno() + "\t" + st.getSname() + "\t" + st.getCourse() + "\t" + st.getFees());
		}
	}
}
