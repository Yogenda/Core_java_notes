package SortingPack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class StdSort2 {

	public static void main(String[] args) {
		List<Student2> lstStd = new ArrayList<Student2>();
		
		Student2 std = new Student2(103, "Lokesh", "Java", 11000.00f);
		lstStd.add(std);
		std = new Student2(102, "Mahesh", "Java", 10000.00f);
		lstStd.add(std);
		std = new Student2(101, "Ramesh", "Java", 15000.00f);
		lstStd.add(std);
		std = new Student2(105, "Suresh", "Java", 12000.00f);
		lstStd.add(std);
		std = new Student2(104, "Naresh", "Java", 13000.00f);
		lstStd.add(std);
		
		
		
		System.out.println("Actual Data");
		for(Student2 st : lstStd)
		{
			System.out.println(st.getRollno() + "\t" + st.getSname() + "\t" + st.getCourse() + "\t" + st.getFees());
		}
		
		SortingBasedOnRollNo sbroll = new SortingBasedOnRollNo();
		Collections.sort(lstStd, sbroll);
		
		System.out.println("Sorted Data Based On Roll Number ");
		for(Student2 st : lstStd)
		{
			System.out.println(st.getRollno() + "\t" + st.getSname() + "\t" + st.getCourse() + "\t" + st.getFees());
		}
		
		SortingBasedOnFees  sbfees = new SortingBasedOnFees();
		Collections.sort(lstStd, sbfees);
		
		System.out.println("Sorted Data Based on Fees");
		for(Student2 st : lstStd)
		{
			System.out.println(st.getRollno() + "\t" + st.getSname() + "\t" + st.getCourse() + "\t" + st.getFees());
		}
	}
}
