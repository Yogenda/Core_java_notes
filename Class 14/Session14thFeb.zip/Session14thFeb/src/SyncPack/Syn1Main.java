package SyncPack;

class  SharedResource
{
	public synchronized void Wish(String name)
	{
		for(int i=1;i<=5;i++)
		{
			System.out.println("Good Morning : " + name);
			try
			{
				Thread.sleep(1000);
			}
			catch(Exception ex)
			{
				
			}
		}
	}	
}


class SyncMethod  extends Thread
{
	private String sname;
	private SharedResource sr;
	
	public SyncMethod(String sname, SharedResource sr)
	{
		this.sname = sname;
		this.sr = sr;
	}
	
	public void run()
	{
		sr.Wish(sname);
	}
}


public class Syn1Main {

	public static void main(String[] args) {
		SharedResource  sr1 = new SharedResource();
		
		SyncMethod  sm1 = new SyncMethod("Venugopal", sr1);
		SyncMethod  sm2 = new SyncMethod("Priya Bhavani", sr1);
		
		sm1.start();
		sm2.start();
	}

}
