package ThreadPack;

class myThread  extends Thread
{
	public void run()  // abstract method of thread class
	{
		System.out.println("This is a Thread ");
	}
}

class myThread1 extends Thread
{
	public void run()
	{
		System.out.println("This is second thread");
	}
}


public class ThreadEx1 {

	public static void main(String[] args) {
		myThread  m1 = new myThread();
			// here every object is be considered as "Thread".
		m1.start();

		myThread1  m2 = new myThread1();
		m2.start();
		
		System.out.println("This is Main method");
	}
}
