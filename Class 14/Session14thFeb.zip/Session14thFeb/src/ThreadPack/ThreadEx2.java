package ThreadPack;

class myth1 implements Runnable
{

	@Override
	public void run() {
		System.out.println("This is runnable interface method-1");
	}
	
}

class myth2 implements Runnable
{

	@Override
	public void run() {
		System.out.println("This is runnable interface method-2");
	}
	
}

public class ThreadEx2 {

	public static void main(String[] args) {
		myth1 mt1 = new myth1();
		Thread th1 = new Thread(mt1);
		th1.start();
		
		Thread th2 = new Thread(new myth2());
		th2.start();
	}

}
