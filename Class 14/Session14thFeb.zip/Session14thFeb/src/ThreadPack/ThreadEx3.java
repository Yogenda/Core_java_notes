package ThreadPack;

class Thrd1 extends  Thread
{
	public void run()
	{
		for(int i=1;i<=5;i++)
		{
			System.out.println("Thread A - " + i);
			try
			{
				Thread.sleep(1000);  // 1000 milli seconds - 1 second
			}
			catch(Exception ex)
			{
				
			}
		}
	}
}

class Thrd2 extends  Thread
{
	public void run()  // running state
	{
		for(int i=1;i<=5;i++)
		{
			System.out.println("Thread B - " + i);
			try
			{
				// blocked state
				Thread.sleep(1000);  // 1000 milli seconds - 1 second
			}
			catch(Exception ex)
			{
				
			}
		}
	}
}

public class ThreadEx3 {

	public static void main(String[] args) {
		
		Thrd1 th = new Thrd1();  // new born state
		th.start();  // runnable state

		Thrd2 th1 = new Thrd2();
		th1.start();
		
	}

}
