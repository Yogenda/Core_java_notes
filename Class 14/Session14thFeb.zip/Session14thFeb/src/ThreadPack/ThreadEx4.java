package ThreadPack;

class myThread11  extends Thread
{
	public void run()  // abstract method of thread class
	{
		System.out.println("This is a Thread ");
	}
}

class myThread12 extends Thread
{
	public void run()
	{
		System.out.println("This is second thread");
	}
}


public class ThreadEx4 {

	public static void main(String[] args) {
		myThread11  m11 = new myThread11();
		m11.start();
		System.out.println("M11 Thread Name : " + m11.getName());
		m11.setName("M11 Thread");
		System.out.println("M11 Thread Name : " + m11.getName());
		myThread12  m12 = new myThread12();
		m12.start();
		System.out.println("M11 Thread Name : " + m12.getName());
		m12.setName("M12 Thread");
		System.out.println("M11 Thread Name : " + m12.getName());
	}
}
