package ThreadPack;

class myThread13  extends Thread
{
	public void run()  // abstract method of thread class
	{
		System.out.println("This is a Thread ");
	}
}

class myThread14 extends Thread
{
	public void run()
	{
		System.out.println("This is second thread");
	}
}


public class ThreadEx5 {

	public static void main(String[] args) {
		myThread13  m13 = new myThread13();
		m13.start();
		//System.out.println("M13 Prority : " + m13.getPriority());
		//m13.setPriority(1); // min priority
		m13.setPriority(Thread.MIN_PRIORITY); // min priority
		System.out.println("M13 Prority : " + m13.getPriority());
		myThread14  m14 = new myThread14();
		m14.start();
		//System.out.println("M14 Prority : " + m14.getPriority());
		//m14.setPriority(10);  // Max Prority
		m14.setPriority(Thread.MAX_PRIORITY); // min priority
		System.out.println("M14 Prority : " + m14.getPriority());
	}
}
