package assgin;

import java.util.List;
import java.util.Scanner;

public class ContactMain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while(true)
		{
		System.out.println("1.Add Contact\r\n"
						+ "2.Display all contacts\r\n"
						+ "3.Search contact by phone \r\n"
						+ "4.Remove contact\r\n"
						+ "5.Exit");
		System.out.println("Pick Your Choice : ");
		int ch = sc.nextInt();
		Contact c = null;
		PhoneBook pb = new PhoneBook();
		switch(ch)
		{
		case 1:
			System.out.println("First Name : ");
			String fname = sc.next();
			System.out.println("Last Name : ");
			String lname = sc.next();
			System.out.println("Phone Number : ");
			long phone = sc.nextLong();
			System.out.println("Email : ");
			String email = sc.next();
			c = new Contact(fname, lname, phone, email);
			pb.addContact(c);
			break;
		case 2:
			List<Contact>  lst1 = pb.viewAllContacts();
			
			for(Contact c1 : lst1)
			{
				System.out.println(c1);
			}
			break;
		case 3:
			System.out.println("Enter Phone Number : ");
			long ph = sc.nextLong();
			Contact ctn = pb.viewContactGivenPhone(ph);
			if(ctn!=null)
				System.out.println(ctn);
			else
				System.out.println("No Contact exist with the given number");
			break;
		case 4:
			System.out.println("Enter Phone Number : ");
			ph = sc.nextLong();
			boolean b = pb.removeContact(ph);
			if(b==true)
				System.out.println("Contact Deleted");
			else
				System.out.println("No Contact exist with the given number");
			break;
		case 5:
			System.out.println("Thanks for using app");
			System.exit(0);
		}
		}
	}
}
