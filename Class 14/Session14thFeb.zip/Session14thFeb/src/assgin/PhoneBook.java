package assgin;
import java.util.*;
public class PhoneBook {
	private static List<Contact> phoneBook = new ArrayList<Contact>();

	public List<Contact> getPhoneBook() {
		return phoneBook;
	}

	public void setPhoneBook(List<Contact> phoneBook) {
		this.phoneBook = phoneBook;
	}
 
	public void addContact(Contact contactObj)
	{
		phoneBook.add(contactObj);
	}
	
	public List<Contact> viewAllContacts()
	{
		return phoneBook;
	}
	
	public Contact viewContactGivenPhone(long phoneNumber)
	{
		Contact cnt = null;
		for(Contact c : phoneBook)
		{
			if(c.getPhoneNumber()==phoneNumber)
			{
				cnt = c;
				break;
			}
		}
		return cnt;
	}
	
	public boolean removeContact(long phoneNumber)
	{
		boolean b = false;
		for(Contact c : phoneBook)
		{
			if(c.getPhoneNumber()==phoneNumber)
			{
				phoneBook.remove(c);
				b = true;
				break;
			}
		}
		
		return b;
	}
}
