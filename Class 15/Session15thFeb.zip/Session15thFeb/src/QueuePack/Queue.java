package QueuePack;

public class Queue {

	private int front, rear, size;
	private int x[];
	
	Queue(int size)
	{
		front = -1;
		rear = -1;
		this.size = size;
		x = new int[size];
	}
	
	public boolean isFull()
	{
		if(rear==this.size-1  &&  front==0)
			return true;
		else
			return false;
	}
	
	public void enQueue(int n)
	{
		if(this.isFull())
		{
			System.out.println("Queue is Full");
			System.exit(0);
		}
		
		if(front==-1)
			front=0;
		//rear++;
		x[++rear] = n;
		System.out.println(n + " Value is Added....");
	}
	
	public boolean isEmpty()
	{
		if(front==-1  && rear==-1)
			return true;
		else
			return false;
	}
	
	public int deQueue()
	{
		
		if(this.isEmpty())
		{
			System.out.println("Queue is Empty");
			System.exit(0);
		}
		int val =  x[front];
		System.out.println("\nDeleted Item : " + val);
		if(front>=rear)
		{
			front = -1;
			rear = -1;
		}
		else
		{
			front++;
		}
		return val;
	}
	
	public void Show()
	{
		if(!this.isEmpty())
		{
			for(int i=front;i<=rear;i++)
			{
				System.out.print(x[i] + "  ");
			}
		}
	}
	
	public int Size()
	{
		return this.size;
	}
	
	public int Peek()
	{
		return x[0];
	}
}
