package QueuePack;

import java.util.PriorityQueue;
import java.util.Queue;

public class QueueEx {

	public static void main(String[] args) {
		Queue<Integer>  queue = new PriorityQueue<Integer>();
		queue.add(101);
		queue.add(102);
		queue.add(103);
		queue.add(104);
		queue.add(105);
		
		System.out.println("Queue Values : " + queue);
		System.out.println("Peek Value : " + queue.peek());
		int cnt = queue.size();
		
		for(int i=1;i<=cnt;i++)
		{
			System.out.println("Removed Item : " + queue.poll());
			System.out.println(queue);
			
			if(queue.isEmpty())
				System.out.println("No values");
		}
		
	}

}
