package QueuePack;

public class QueueMain {

	public static void main(String[] args) {
		Queue q = new Queue(5);
		
		q.enQueue(10);
		q.enQueue(20);
		q.enQueue(30);
		q.enQueue(40);
		q.enQueue(50);
		
		//q.enQueue(60);
		
		q.Show();
		
		int cnt = q.Size();
		
		for(int i=1;i<=cnt;i++)
		{
			System.out.println(q.deQueue());
			q.Show();
			if(q.isEmpty())
				System.out.println("No Values ");
		}
		
	}

}
