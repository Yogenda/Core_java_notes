package StackPack;
// Stack st = new Stack(10)
public class Stack {

	private int top;
	private int size;
	private int x[];
	
	public Stack(int size)
	{
		top = -1;
		this.size = size;
		x = new int[this.size];
	}
	
	public boolean isFull()
	{
		if(top==this.size-1)
			return true;
		else
			return false;
	}
	
	public void Push(int n)
	{
		if(this.isFull())
		{
			System.out.println("Stack is Overflow");
			System.exit(0);
		}
		x[++top] = n;
		System.out.println(n + " Value Add");
	}
	
	public boolean isEmpty()
	{
		if(top==-1)
			return true;
		else
			return false;
	}
	
	public int Pop()
	{
		if(this.isEmpty())
		{
			System.out.println("Stack is Empty");
			System.exit(0);
		}
		return x[top--];
	}
	
	public void Show()
	{
		for(int i=0;i<=top;i++)
		{
			System.out.print(x[i] + "  ");
		}
	}
	
	public int Size()
	{
		return this.size;
	}
	
	public int Peek()
	{
		if(this.isEmpty())
		{
			System.out.println("Stack is Empty");
			System.exit(0);
		}
		return  x[top];
	}
}
