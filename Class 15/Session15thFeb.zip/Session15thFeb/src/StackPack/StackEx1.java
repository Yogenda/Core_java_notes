package StackPack;

import java.util.Stack;

public class StackEx1 {

	public static void main(String[] args) {
		
		Stack<Integer>  stk = new Stack<Integer>();

		stk.push(101);
		stk.push(102);
		stk.push(103);
		stk.push(104);
		stk.push(105);
		
		System.out.println(stk);
		System.out.println("Peek Value " + stk.peek());
		int size = stk.size();
		for(int i=1;i<=size;i++)
		{
			System.out.println("Removed Item : " + stk.pop());
			System.out.println(stk);
			
			if(stk.isEmpty())
				System.out.println("No Items are present");
		}
		
	}

}
