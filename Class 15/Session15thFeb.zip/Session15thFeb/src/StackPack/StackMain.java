package StackPack;

public class StackMain {

	public static void main(String[] args) {
		Stack  stk = new Stack(5);
		
		stk.Push(11);
		stk.Push(12);
		stk.Push(13);
		stk.Push(14);
		stk.Push(15);
		//stk.Push(16);// stack overflow
		System.out.println("Stack Values ");
		stk.Show();
		System.out.println();
		int cnt = stk.Size();
		
		for(int i=1;i<=cnt;i++)
		{
			System.out.println("\nRemoved Item : " + stk.Pop());
			stk.Show();
			if(stk.isEmpty())
				System.out.println("No values are present");
		}
	}

}
