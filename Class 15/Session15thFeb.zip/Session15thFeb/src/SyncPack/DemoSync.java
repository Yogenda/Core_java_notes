package SyncPack;
//Write a program for Synchronization(Method)
/*
 * Task 1 : print all Even Numbers b/w 1 - n
 * Task :-  Print all factors of 5  upto n
 */

import java.util.Scanner;

class SharedItem
{
	public synchronized void printalleven_numbers(int n)
	{
		System.out.println("\nEven Numbers ");
		for(int i=2;i<=n;i+=2)
		{
			System.out.print(i + "  ");
			try
			{
				Thread.sleep(1000);
			}
			catch(Exception ex) {}
		}
	}
	
	public synchronized void printall_factors_of_5(int n)
	{
		System.out.println("\nFactors of 5 ");
		for(int i=5;i<=n;i+=5)
		{
			System.out.print(i + "  ");
			try
			{
				Thread.sleep(1000);
			}
			catch(Exception ex) {}
		}
	}
}


class EvenNumbers  extends Thread
{
	private int n;
	private SharedItem si;
	
	EvenNumbers(int n, SharedItem si)
	{
		this.n = n;
		this.si = si;
	}
	
	public void run()
	{
		si.printalleven_numbers(n);
	}
}

class Factors  extends Thread
{
	private int n;
	private SharedItem si;
	
	Factors(int n, SharedItem si)
	{
		this.n = n;
		this.si = si;
	}
	
	public void run()
	{
		si.printall_factors_of_5(n);
	}
}

public class DemoSync {

	public static void main(String[] args) {
		SharedItem si = new SharedItem();
		
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter any number ");
		int n = sc.nextInt();
		
		EvenNumbers  en = new EvenNumbers(n, si);
		Factors  ft = new Factors(n, si);
		
		en.start();
		
		ft.start();
		

	}

}
