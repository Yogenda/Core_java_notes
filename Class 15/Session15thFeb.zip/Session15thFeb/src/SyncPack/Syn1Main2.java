package SyncPack;
// Block Level Sync
class  SharedResourceForBlockLevel
{
	public void Wish(String name)
	{
		System.out.println("Thread has Started....");
		synchronized(this)
		{
			for(int i=1;i<=5;i++)
			{
				System.out.println("Good Morning : " + name);
				try
				{
					Thread.sleep(1000);
				}
				catch(Exception ex)
				{
					
				}
			}
		}
		//System.out.println("End of Thread");
	}	
}

class SyncBlock  extends Thread
{
	private String sname;
	private SharedResourceForBlockLevel sr;  // null object
	
	public SyncBlock(String sname, SharedResourceForBlockLevel sr)
	{
		this.sname = sname;
		this.sr = sr;
	}
	
	public void run()
	{
		sr.Wish(sname);
	}
}


public class Syn1Main2 {

	public static void main(String[] args) {
		SharedResourceForBlockLevel  sr1 = new SharedResourceForBlockLevel();
		
		SyncBlock  sm1 = new SyncBlock("Venugopal", sr1);
		SyncBlock  sm2 = new SyncBlock("Priya Bhavani", sr1);
		
		sm1.start();
		sm2.start();
	}
}
