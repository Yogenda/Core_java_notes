package SyncPack;
// Static Sync
class  SharedResourceStaticLevel
{
	public synchronized static void Wish(String name)
	{
		for(int i=1;i<=5;i++)
		{
			System.out.println("Good Morning : " + name);
			try
			{
				Thread.sleep(1000);
			}
			catch(Exception ex)
			{
				
			}
		}
	}	
}

class SyncStatic  extends Thread
{
	private String sname;
	
	
	public SyncStatic(String sname)
	{
		this.sname = sname;
	}
	
	public void run()
	{
		SharedResourceStaticLevel.Wish(sname);
	}
}


public class Syn1Main3 {

	public static void main(String[] args) {
		
		
		SyncStatic  sm1 = new SyncStatic("Venugopal");
		SyncStatic  sm2 = new SyncStatic("Priya Bhavani");
		
		sm1.start();
		sm2.start();
	}
}
