package SortPack;

public class BubbleSort {

	public static void main(String[] args) {
		int x[] = {2,1,8,9,4};
		
		System.out.println("Actual Values ");
		
		for(int i=0;i<x.length;i++)
		{
			System.out.print(x[i] + "\t");
		}
	
		for(int i=0;i<x.length;i++)
		{
			for(int j=i+1;j<x.length;j++)
			{
				if(x[i]>x[j])
				{
					int temp = x[i];
					x[i] = x[j];
					x[j] = temp;
				}
			}
		}
	
		System.out.println("\nSorted Values ");
		
		for(int i=0;i<x.length;i++)
		{
			System.out.print(x[i] + "\t");
		}

	}

}
