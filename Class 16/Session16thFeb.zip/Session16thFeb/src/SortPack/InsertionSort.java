package SortPack;

public class InsertionSort {

	public static void main(String[] args) {
		int x[] = {2,1,8,9,4};
		
		System.out.println("Actual Values ");
		
		for(int i=0;i<x.length;i++)
		{
			System.out.print(x[i] + "\t");
		}
	
		for(int i=1;i<x.length;i++)
		{
			int temp = x[i];
			int j = i-1;
			while(j>=0 && x[j]>temp)
			{
				x[j+1] = x[j];
				j--;
			}
			
			x[j+1] = temp;
		}
	
		System.out.println("\nSorted Values ");
		
		for(int i=0;i<x.length;i++)
		{
			System.out.print(x[i] + "\t");
		}

	}

}
