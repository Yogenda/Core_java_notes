package FunctionPack;

public class Fun1 {

	static void Sample()
	{
		System.out.println("This is user defined method");
	}
	
	static void Simple(int x, float y)
	{
		System.out.println("X value : " + x);
		System.out.println("Y value : " + y);
		System.out.println("Add : " +(x+y));
	}
	
	public static void main(String[] args) {
		System.out.println("This is Main() method");
		Sample();// calling of the method.
		System.out.println("----------------");
		Simple(10,12.34f);
		
		int p = 100;
		float q = 45.67f;
		
		Simple(p, q);
		
		System.out.println("----------------");
		System.out.println("End of the main() method");
		
	}

	
	
	
}
