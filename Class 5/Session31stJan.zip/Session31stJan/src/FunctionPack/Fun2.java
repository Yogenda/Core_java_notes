package FunctionPack;

import java.util.Scanner;

public class Fun2 {
// Accept a value then calculate it's factorial value 
	// using without arg and without return value.
	
	static void Factorial()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter any value ");
		int x = sc.nextInt();
		
		int fact = 1;
		while(x>0)
		{
			fact = fact*x;
			x--;
		}
		
		System.out.println("Factorial Value : " + fact);
	}
		
	public static void main(String[] args) {
		
		Factorial();
	}
}
