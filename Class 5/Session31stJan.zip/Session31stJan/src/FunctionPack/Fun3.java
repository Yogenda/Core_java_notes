package FunctionPack;

import java.util.Scanner;

public class Fun3 {
// Accept a value then calculate it's factorial value 
	// using with arg and without return value.
	
	static void Factorial(int x)
	{
	
		
		int fact = 1;
		while(x>0)
		{
			fact = fact*x;
			x--;
		}
		
		System.out.println("Factorial Value : " + fact);
	}
		
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
			System.out.println("Enter any value ");
			int n = sc.nextInt();
		Factorial(n);
	}
}
