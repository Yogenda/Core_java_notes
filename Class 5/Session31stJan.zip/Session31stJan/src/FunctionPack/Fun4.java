package FunctionPack;

public class Fun4 {

	// With arguments and with return value.
	
	static float Simple(int x, float y)
	{
		System.out.println("X value : " + x);
		System.out.println("Y value : " + y);
		float add = x+y;
		return add;
	}
	
	public static void main(String[] args) {
		
		float res = Simple(10,12.34f);
		System.out.println("Addition : " + res);
		
		System.out.println("Add Val : " + Simple(45,67.78f));
	}	
}
