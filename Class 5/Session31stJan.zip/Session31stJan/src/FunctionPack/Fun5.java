package FunctionPack;

import java.util.Scanner;

public class Fun5 {

	/*
	 * Calculate result of the following formula using with arg and with return value
	 * 
	 * ncr = n!/r!*(n-r)!
	 *
	 */
	

	static int factorial(int x)
	{
		int fact = 1;
		while(x>0)
		{
			fact = fact*x;
			x--;
		}
		
		return fact;
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter N, R values ");
		int n = sc.nextInt();
		int r = sc.nextInt();
		
		int ncr = factorial(n)/(factorial(r)*factorial(n-r));
		
		System.out.println(n + " C " + r + " = " + ncr);
	}	
}
