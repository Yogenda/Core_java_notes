package FunctionPack;

import java.util.Scanner;

public class Fun6 {
// Accept a value then calculate it's factorial value 
	// using without arg and with return value.
	
	static int Factorial()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter any value ");
		int x = sc.nextInt();
		
		int fact = 1;
		while(x>0)
		{
			fact = fact*x;
			x--;
		}
		
		return fact;	
	}
		
	public static void main(String[] args) {
		
		System.out.println("Fact vALUE IS " + Factorial());
	}
}
