package StringPack;
import java.util.Scanner;
public class StrEx2 {
// check  given two string are equal or not.
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Two Strings ");
		String st1 = sc.next();
		String st2 = sc.next();
		
		if(st1.equals(st2))
			System.out.println("Both Strings are Same");
		else
			System.out.println("Both Strings are not same");
	}
}
