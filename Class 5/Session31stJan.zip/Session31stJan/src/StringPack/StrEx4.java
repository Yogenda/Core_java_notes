package StringPack;
import java.util.Scanner;
public class StrEx4 {
// concatenate two strings 
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Two Strings ");
		String st1 = sc.next();
		String st2 = sc.next();
		
		System.out.println(st1.concat(st2));
		System.out.println(st1);
		System.out.println(st2);
	}
}
