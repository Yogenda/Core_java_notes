package StringPack;
import java.util.Scanner;
public class StrEx5 {
// check  given two string are big/small/equals
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Two Strings ");
		String st1 = sc.next();
		String st2 = sc.next();
		
		if(st1.compareTo(st2)>0)
			System.out.println("First String is BIg");
		else if(st1.compareTo(st2)<0)
			System.out.println("Second string is big");
		else if(st1.compareTo(st2)==0)
			System.out.println("Both are same");
	}
}
