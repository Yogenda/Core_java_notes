package StringPack;

public class StrEx6 {
// String array initilization
	public static void main(String[] args) {
		String str[] = {"Java Course", "Online Training", "Simpli Learn"};
		
		for(int i=0;i<str.length;i++)
		{
			System.out.println(str[i] + " Length " + str[i].length());
		}
	}
}
