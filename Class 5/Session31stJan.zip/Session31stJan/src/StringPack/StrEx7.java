package StringPack;
import java.util.Scanner;
public class StrEx7 {
// String array with inputs dynamically
	public static void main(String[] args) {
		String str[] = new String[5];
		Scanner sc = new Scanner(System.in);

		for(int i=0;i<str.length;i++)
		{
			System.out.println("Enter " + (i+1) + " String");
			str[i] = sc.nextLine();
		}
		System.out.println("Array of Strings ");
		for(int i=0;i<str.length;i++)
		{
			System.out.println(str[i] + " Length " + str[i].length());
		}
	}
}
