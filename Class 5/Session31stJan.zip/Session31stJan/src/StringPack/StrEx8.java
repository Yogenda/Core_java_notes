package StringPack;
import java.util.Scanner;
public class StrEx8 {
//check a substring existed or not in a string
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter any String in sentence format ");
		String st1 = sc.nextLine();
		System.out.println("Enter String to search");
		String st2 = sc.nextLine();
		
		if(st1.contains(st2))
			System.out.println("Existed");
		else
			System.out.println("Not Existed");
	}
}
