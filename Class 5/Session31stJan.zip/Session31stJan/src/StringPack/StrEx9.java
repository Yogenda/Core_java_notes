package StringPack;
import java.util.Scanner;
public class StrEx9 {
//count the following items from string 
	/*
	 * no of alphabets
	 * no of digits
	 * no of symbols
	 * no of spaces
	 */
	
	public static void main(String[] args) {
		String str = "door no: 12/34-A/b";
		int a=0, d=0, sp=0, sy=0;
		
		for(int i=0;i<str.length();i++)
		{
			char ch = str.charAt(i);
			if((ch>=65 && ch<=90) || (ch>=97 && ch<=122))
				a++;
			else if(ch>='0' && ch<='9')
				d++;
			else if(ch==' ')
				sp++;
			else
				sy++;
		}
		
		System.out.println("Alphabets : " + a);
		System.out.println("Digits : " + d);
		System.out.println("Spaces : " + sp);
		System.out.println("Symbols : " + sy);
	}
}

