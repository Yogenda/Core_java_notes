package Assignment;

import java.util.Scanner;

public class StdMain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Student ID ");
		int sid = sc.nextInt();
		System.out.println("Student Name : ");
		String sname = sc.next();
		System.out.println("Student Address : ");
		String adrs = sc.next();
		
		while(true)
		{
			System.out.println("Are u from NIT College(yes/no)");
			String ch = sc.next();
			if(ch.equalsIgnoreCase("Yes") || ch.equalsIgnoreCase("No"))
			{
				if(ch.equalsIgnoreCase("yes"))
				{
					Student std = new Student(sid, sname, adrs);
					System.out.println("Student ID : " + std.getStudentId());
					System.out.println("Student Name : " + std.getStudentName());
					System.out.println("Student Address : " + std.getStudentAddress());
					System.out.println("College Name : " + std.getCollegeName());
				}
				else
				{
					System.out.println("College name ");
					String clg = sc.next();
					Student std = new Student(sid, sname, adrs, clg);
					System.out.println("Student ID : " + std.getStudentId());
					System.out.println("Student Name : " + std.getStudentName());
					System.out.println("Student Address : " + std.getStudentAddress());
					System.out.println("College Name : " + std.getCollegeName());				
				}
				break;
			}
			else
				System.out.println("Wrong Input");
		}
	}
}
