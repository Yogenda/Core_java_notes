package Assignment;

import java.util.Scanner;

public class TicketMain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Ticket tkt = new Ticket();
		System.out.println("Enter  No of Available Tickets ");
		Ticket.setAvailableTickets(sc.nextInt());
		System.out.println("Enter no of Bookings ");
		int bk = sc.nextInt();
		
		for(int i=1;i<=bk;i++)
		{
			System.out.println("Ticket ID ");
			tkt.setTicketid(sc.nextInt());
			System.out.println("Enter Price ");
			tkt.setPrice(sc.nextInt());
			System.out.println("No of Tickets ");
			int nooftkts = sc.nextInt();
			
			int res = tkt.calculateTicketCost(nooftkts);
			
			if(res==-1)
			{
				System.out.println("No tickets are exist");
				break;
			}
			else
			{
				System.out.println("Total Amount : "+ res);
			}
			System.out.println("Avaiable Tickets : " + Ticket.getAvailableTickets());
			System.out.println("----------------------");
		}
	}
}
