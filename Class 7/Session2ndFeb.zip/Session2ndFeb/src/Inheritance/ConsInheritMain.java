package Inheritance;

public class ConsInheritMain {

	public static void main(String[] args) {
		Child1 ch = new Child1();
		System.out.println("----------------------");
		Child2 ch1 = new Child2(100,20,30);
	}

}
