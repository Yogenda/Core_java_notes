package Inheritance;

public class MulMain {

	public static void main(String[] args) {
		MarksSheet ms = new MarksSheet();
		ms.getStdInfo("Kiran", "Java");
		ms.getMarksInfo(56, 60);
		ms.printResults();
	}

}
