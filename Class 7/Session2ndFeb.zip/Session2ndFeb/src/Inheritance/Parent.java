package Inheritance;
// Single Inheritance
public class Parent {
	protected int x, y;
	
	void getdata(int x, int y)
	{
		this.x = x;
		this.y = y;
	}
}

class Child extends Parent
{
	private int sum;
	
	void putdata()
	{
		sum = x+y;
		System.out.println("X : " + x);
		System.out.println("Y : " + y);
		System.out.println("Sum : " + sum);
	}
}
