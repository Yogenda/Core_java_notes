package Inheritance;
// constructor in inheritance
public class Parent1 {

	
	
	Parent1()
	{
		System.out.println("Parent class constructor");
	}
}

class Child1 extends Parent1
{
	
	
	Child1()
	{
		System.out.println("child class constructor");
	}
}
