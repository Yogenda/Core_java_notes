package Inheritance;
// constructor with arg in inheritance
public class Parent2 {

	
	
	Parent2(int p, int q)
	{
		System.out.println("Parent class constructor");
		System.out.println("P = " + p + "\t" + "Q = " + q);
	}
}

class Child2 extends Parent2
{
	
	
	Child2(int a, int b, int c)
	{
		super(b,c);
		System.out.println("child class constructor");
		System.out.println("A = " + a);
	}
}
