package Inheritance;

public class SinMain {

	public static void main(String[] args) {

		Child ch = new Child();
		ch.getdata(10, 20);
		ch.putdata();
	}
}
