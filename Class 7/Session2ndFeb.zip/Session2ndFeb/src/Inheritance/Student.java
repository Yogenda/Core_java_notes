package Inheritance;

public class Student {

	protected String sname, course;
	
	void getStdInfo(String sname, String course)
	{
		this.sname = sname;
		this.course = course;
	}
}

class Marks extends Student
{
	protected int sub1, sub2;
	
	void getMarksInfo(int sub1, int sub2)
	{
		this.sub1 = sub1;
		this.sub2 = sub2;
	}
}

class MarksSheet extends Marks
{
	void printResults()
	{
		System.out.println("Student Name : " + sname);
		System.out.println("Course : " + course);
		System.out.println("Subject 1 Marks " + sub1);
		System.out.println("Subject 2 Marks " + sub2);
		System.out.println("Total Marks " + (sub1+sub2));
	}
}