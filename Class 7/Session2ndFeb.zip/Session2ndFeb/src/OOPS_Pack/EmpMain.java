package OOPS_Pack;

public class EmpMain {

	public static void main(String[] args) {
		EmpProcess ep = new EmpProcess();
		ep.getempDetails();
		ep.printEmpDetails();
	}
}
