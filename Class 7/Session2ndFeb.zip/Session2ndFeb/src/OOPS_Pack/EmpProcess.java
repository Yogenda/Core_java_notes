package OOPS_Pack;

import java.util.Scanner;

public class EmpProcess {
	private Scanner sc = new Scanner(System.in);
	private Employee emp = new Employee();
	
	void getempDetails()
	{
		System.out.println("Employee Number ");
		emp.setEmpno(sc.nextInt());
		System.out.println("Employee Name : ");
		emp.setEname(sc.next());
		System.out.println("Employee Job : ");
		emp.setJob(sc.next());
		System.out.println("Employee Salary");
		emp.setSal(sc.nextFloat());
	}
	
	void printEmpDetails()
	{
		System.out.println("Employee  Number : " + emp.getEmpno());
		System.out.println("Employee  Name : " + emp.getEname());
		System.out.println("Employee  Job : " + emp.getJob());
		System.out.println("Employee  Salary : " + emp.getSal());
	}
}
