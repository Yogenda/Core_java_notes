package OOPS_Pack;

public class GSMain {

	public static void main(String[] args) {
			GettersAndSetters  gs = new GettersAndSetters();
			gs.setX(100);
			System.out.println("Given Value : " + gs.getX());
	}

}
