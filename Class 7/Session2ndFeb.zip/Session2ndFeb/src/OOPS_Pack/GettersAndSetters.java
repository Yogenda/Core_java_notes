package OOPS_Pack;

public class GettersAndSetters {
		private int x;
		
		void setX(int x)
		{
			this.x = x;
		}
		
		int getX()
		{
			return x;
		}
}
