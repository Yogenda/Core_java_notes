package AbstractionPack;

public class AbsMain {

	public static void main(String[] args) {
		DemoAbsChild db = new DemoAbsChild();
		db.getval(10);
		db.putVal();
	}
}
