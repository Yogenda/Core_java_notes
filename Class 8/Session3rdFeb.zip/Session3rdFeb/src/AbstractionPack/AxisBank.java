package AbstractionPack;

public class AxisBank extends Bank {

	@Override
	void createNewAccount() {
		// TODO Auto-generated method stub
		
	}

	@Override
	float rateofInterest() {
		// TODO Auto-generated method stub
		return 0;
	}
}
