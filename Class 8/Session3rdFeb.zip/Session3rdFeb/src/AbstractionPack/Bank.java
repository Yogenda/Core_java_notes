package AbstractionPack;

public abstract class Bank {
	abstract void createNewAccount();
	abstract float rateofInterest();
}

class  SBI extends Bank
{

	@Override
	void createNewAccount() {
		// TODO Auto-generated method stub
		System.out.println("New Account Process for SBI");
	}

	@Override
	float rateofInterest() {
		// TODO Auto-generated method stub
		return 5.6f;
	}
	
}


class HDFC extends Bank
{

	@Override
	void createNewAccount() {
		// TODO Auto-generated method stub
		System.out.println("New Account Process for HDFC");
	}

	@Override
	float rateofInterest() {
		// TODO Auto-generated method stub
		return 6.7f;
	}
}


// Desgin Patterns  :- these are the prinicples of application development.
// Factory methods  :- Generic methods.