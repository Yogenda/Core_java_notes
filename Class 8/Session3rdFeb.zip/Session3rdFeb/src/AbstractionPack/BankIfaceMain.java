package AbstractionPack;

interface PersonalBanking
{
	void createNewAccount();
	void checkBalance();
}

interface  Loan
{
	float rateofInterest();
}

// multiple inheritance
class SBIBank implements PersonalBanking, Loan
{

	@Override
	public float rateofInterest() {
		// TODO Auto-generated method stub
		return 5.6f;
	}

	@Override
	public void createNewAccount() {
		// TODO Auto-generated method stub
		System.out.println("New SBI Acc");
	}

	@Override
	public void checkBalance() {
		// TODO Auto-generated method stub
		System.out.println("SBI Check Bal");
	}
}

public class BankIfaceMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SBIBank sbi = new SBIBank();
		sbi.createNewAccount();
		sbi.checkBalance();
		System.out.println("Rate of Interest for SBI " + sbi.rateofInterest());
	}

}
