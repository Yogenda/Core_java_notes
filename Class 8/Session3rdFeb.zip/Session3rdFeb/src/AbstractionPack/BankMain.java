package AbstractionPack;

public class BankMain {

	public static void main(String[] args) {
		SBI sbi = new SBI();
		sbi.createNewAccount();
		System.out.println("Rate of Interest of SBI : " + sbi.rateofInterest());
		
		HDFC hdfc = new HDFC();
		hdfc.createNewAccount();
		System.out.println("Rate of Interest of HDFC : " + hdfc.rateofInterest());
	}

}
