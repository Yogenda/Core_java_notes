package AbstractionPack;

public abstract class DemoAbs {
	protected int x;
	void getval(int x)
	{
		this.x = x;
	}
	
	abstract void putVal();  // abstract methods
}


class DemoAbsChild extends  DemoAbs
{
	private int sqr;
	@Override
	void putVal() {

		sqr = x*x;
		System.out.println(x + " Sqaure Value " + sqr);
	}
	
}
