package AbstractionPack;

interface shape
{
	void get(int x);
	void put();
}

/*
 * abstract class shape
 * {
 * 	abstract void get(int x);
 *  abstract void put();
 * 	}
 */
class Square implements shape
{
	private int x;
	@Override
	public void get(int x) {
		// TODO Auto-generated method stub
		this.x = x;
	}

	@Override
	public void put() {
		// TODO Auto-generated method stub
		System.out.println(x + " Square Value " + (x*x));
	}
	
}


class Cube implements shape
{
	private int x;
	@Override
	public void get(int x) {
		// TODO Auto-generated method stub
		this.x = x;
	}

	@Override
	public void put() {
		// TODO Auto-generated method stub
		System.out.println(x + " Cube Value " + (x*x*x));
	}
}

public class DemoIface {

	public static void main(String[] args)
	{
		Square s = new Square();
		s.get(10);
		s.put();
		
		Cube  c = new Cube();
		c.get(20);
		c.put();
	}
}
