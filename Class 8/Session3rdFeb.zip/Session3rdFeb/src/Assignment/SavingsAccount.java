package Assignment;

public class SavingsAccount extends Account {
	private double minimumBalance;	
	
	public SavingsAccount(int accountNumber, Customer customerObj, double balance, double minimumBalance) {
		super(accountNumber, customerObj, balance);
		this.minimumBalance = minimumBalance;
	}
	
	@Override
	public boolean withdraw(double amount) {
		if((balance-amount)>minimumBalance)
		{
			balance = balance-amount;
			return true;
		}
		else
			return false;
	}
	
	public void printCustomerInfo()
	{
		System.out.println("Customer ID : " + customerObj.getCustomerId());
		System.out.println("Customer Name : " + customerObj.getCustomerName());
		System.out.println("Customer Email : " + customerObj.getEmailId());
		System.out.println("Account Number : " +  accountNumber);
		System.out.println("Present Balance : " + balance);
		System.out.println("Minimum Balance : " + minimumBalance);
	}
}
