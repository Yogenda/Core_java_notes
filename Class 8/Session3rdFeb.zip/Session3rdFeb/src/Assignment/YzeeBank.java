package Assignment;

import java.util.Scanner;

public class YzeeBank {

	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	
	System.out.println("Customer ID");
	int cid = sc.nextInt();
	
	System.out.println("Customer Name : ");
	String cname = sc.next();
	
	System.out.println("Email ID");
	String email = sc.next();
	
	Customer cust = new Customer(cid, cname, email);
	
	System.out.println("Account No : ");
	int accno = sc.nextInt();
	
	System.out.println("Total Amount for Depositing ");
	double tamt = sc.nextDouble();
	
	System.out.println("Mini Balance ");
	double mbal = sc.nextDouble();
	
	SavingsAccount  sa = new SavingsAccount(accno, cust, tamt, mbal);
	
	sa.printCustomerInfo();
	
	System.out.println("------------------");
	System.out.println("How much amount to with draw ");
	double amt = sc.nextDouble();
	
	boolean b = sa.withdraw(amt);
	
	if(b==true)
		System.out.println("Withdraw Successfull");
	else
		System.out.println("Insufficient Funds");
	}
}
