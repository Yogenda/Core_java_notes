package PolyPack;

public class DemoParent {

	void GetVal(int x)
	{
		System.out.println("X value from parent class : " + x);
	}
}
class DemoChild extends DemoParent
{
	void GetVal(int x)
	{
		System.out.println("X value from child class : " + x);
	}	
}

