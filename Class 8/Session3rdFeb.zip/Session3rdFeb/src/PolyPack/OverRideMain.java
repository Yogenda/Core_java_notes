package PolyPack;

public class OverRideMain {

	public static void main(String[] args) {
		DemoParent dp = new DemoParent();
		dp.GetVal(100); // parent class method
		DemoChild dc = new DemoChild();
		dp = dc;  // overriding
		// or
		//dp = new DemoChild();
		dp.GetVal(10);  // child class method
	}

}
