package PolyPack;

public class Poly1 {

	static void Area(float r)
	{
		System.out.println("Area of Circle is " + (3.14f*r*r));
	}
	
	static void Area(int l, int b)
	{
		System.out.println("Area of Rectangle is : " + (l*b));
	}
	
	static void Area(float b, float h)
	{
		System.out.println("Area of Traingle is : " + (0.5f*b*h));
	}
}
