package PolyPack;

public class Poly2 {

	void Big(int x, int y)
	{
		if(x>y)
			System.out.println(x + " and "  + y + " Big No " + x);
		else
			System.out.println(x + " and "  + y + " Big No " + y);
	}

	void Big(float x, float y)
	{
		if(x>y)
			System.out.println(x + " and "  + y + " Big No " + x);
		else
			System.out.println(x + " and "  + y + " Big No " + y);
	}

	void Big(int x, float y)
	{
		if(x>y)
			System.out.println(x + " and "  + y + " Big No " + x);
		else
			System.out.println(x + " and "  + y + " Big No " + y);
	}

}
