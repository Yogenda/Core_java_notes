package PolyPack;

public class PolyMain {

	public static void main(String[] args) 
	{
			Poly1.Area(1.5f, 1.6f);
			Poly1.Area(4,5);
			Poly1.Area(1.5f);
			System.out.println("------------------");
			Poly2 p2 = new Poly2();
			p2.Big(4, 5);
			p2.Big(1.4f, 1.2f);
			p2.Big(10, 12.5f);
	}
}
