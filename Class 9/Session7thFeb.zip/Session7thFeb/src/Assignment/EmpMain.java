package Assignment;

import java.util.Scanner;

public class EmpMain {

	
	public static Employee getEmployeeDetails()
	{
		Employee emp = new  Employee();
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Emp ID");
		emp.setEmployeeId(sc.nextInt());
		System.out.println("Emp Name ");
		emp.setEmployeeName(sc.next());
		System.out.println("Salary ");
		emp.setSalary(sc.nextDouble());
		
		return emp;
	}
	
	public static int getPFPercentage()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter PF Percentage");
		int pf = sc.nextInt();
		return pf;
	}
	public static void main(String[] args) {
		
		Employee empinfo = getEmployeeDetails();
		empinfo.calculateNetSalary(getPFPercentage());
		
		System.out.println("Emp Id : " + empinfo.getEmployeeId());
		System.out.println("Emp Name : " + empinfo.getEmployeeName());
		System.out.println("Emp Salary : " + empinfo.getSalary());
		System.out.println("Emp Net Salary : " + empinfo.getNetSalary());
	}

}
