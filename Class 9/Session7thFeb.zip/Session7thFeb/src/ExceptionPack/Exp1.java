package ExceptionPack;

import java.util.Scanner;

public class Exp1 {

	public static void main(String[] args) {
		try
		{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter two values ");
		int x = sc.nextInt();
		int y = sc.nextInt();
		
		int div = x/y;
		
		System.out.println("Division : " + div);
		}
		catch(Exception ex)
		{
			System.out.println(ex);
			System.out.println("Value should not divide with zero");
		}
		finally
		{
			System.out.println("this is Finally Block");
		}
	}
}
