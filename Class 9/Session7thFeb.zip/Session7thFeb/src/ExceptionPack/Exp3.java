package ExceptionPack;

import java.io.IOException;

public class Exp3 {

	public static void main(String[] args) throws IOException {
		System.out.println("Enter any alphabet ");
		int ch = System.in.read();
		
		System.out.println("Given Alphaet : " + (char)ch);
	}

}
