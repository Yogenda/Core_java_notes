package ExceptionPack;

import java.io.IOException;

public class Exp4 {

	public static void main(String[] args) {
		try
		{
		System.out.println("Enter any alphabet ");
		int ch = System.in.read();
		
		System.out.println("Given Alphaet : " + (char)ch);
		}
		catch(IOException ex)
		{
			System.out.println(ex);
		}
	}

}
