package ExceptionPack;
import java.util.Scanner;

public class Exp5 {

	public static void main(String[] args) {
		try
		{
			Scanner sc = new Scanner(System.in);
			float balance = 14000.00f;
			System.out.println("Enter EMI Amount");
			int emi = sc.nextInt();
			
			if(balance>=emi)
				System.out.println("EMI Deducted from your account successfully");
			else
				throw new InsufficientFundException("Insufficent EMI Amount");
		}
		catch(InsufficientFundException  em)
		{
				System.out.println(em);
		}
	}

}
