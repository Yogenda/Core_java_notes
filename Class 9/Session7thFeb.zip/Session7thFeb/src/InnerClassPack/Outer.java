package InnerClassPack;

public  class Outer {

	private int n;
	
	void get(int n)
	{
		this.n = n;
	}
	
	class Inner
	{
		private int sq;
		
		void put()
		{
			sq = n*n;
			System.out.println(n + " Square Value is " + sq);
		}
	}
}

