package InnerClassPack;

public class Outer2 {

	private int n;
	
	void get(int n)
	{
		this.n = n;
	}
	
	
	void show()
	{
		class Inner2
		{
			private int sq;
			
			void put()
			{
				sq = n*n;
				System.out.println(n + " Square Value is " + sq);
			}
		}
		
		Inner2  i2 = new Inner2();
		i2.put();
	}
	
}

