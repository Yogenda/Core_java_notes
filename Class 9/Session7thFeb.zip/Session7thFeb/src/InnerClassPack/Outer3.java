package InnerClassPack;

public class Outer3 {

	private static int n;
	
	void GetVal(int x)
	{
		n = x;
	}
	/*
	static void print()
	{
		System.out.println("Print Method");
	}
	*/
	static class Inner3
	{
		private int sq;
		
		void  Square()
		{
			sq = n*n;
			System.out.println(n +" Sqaure Value " + sq);
		}
		
		static void Cube()
		{
			System.out.println(n + " Cube Value is " + (n*n*n));
		}
	}
}
