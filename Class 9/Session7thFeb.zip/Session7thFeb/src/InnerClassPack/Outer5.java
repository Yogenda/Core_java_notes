package InnerClassPack;

public  class Outer5 {

	private int n;
	
	void get(int n)
	{
		this.n = n;
	}
	
	class Inner1
	{
		private int sq;
		
		void Square()
		{
			sq = n*n;
			System.out.println(n + " Square Value is " + sq);
		}
	}
	
	class Inner2 extends Inner1
	{
		private int cb;
		
		void cube()
		{
			cb = n*n*n;
			System.out.println(n + " Cube Value is " + cb);
		}
	}
}

