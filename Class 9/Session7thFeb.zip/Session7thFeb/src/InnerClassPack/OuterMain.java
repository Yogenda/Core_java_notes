package InnerClassPack;

public class OuterMain {

	public static void main(String[] args) {
		System.out.println("---------Member Inner Class----");
		Outer o1 = new Outer();
		o1.get(10);
		Outer.Inner  i1 = o1. new Inner();
		i1.put();
		System.out.println("---------Member Inner Class with interface----");
		Outer4 o4 = new Outer4();
		o4.get(10);
		Outer4.Inner4  i4 = o4. new Inner4();
		i4.put();
		System.out.println("---------Local Inner Class----");
		Outer2  o2 = new Outer2();
		o2.get(10);
		o2.show();
		
		System.out.println("---------Static Inner Class----");
		
		Outer3  o3 = new Outer3();
		o3.GetVal(10);
		Outer3.Inner3  i3 = new Outer3.Inner3();
		i3.Square();
		//To call static method from inner class
		// OUterClass.InnerClass.methodname()
		Outer3.Inner3.Cube();
		//Outer3.print();
		
		System.out.println("--- Memer Inner CLas with Inheritance of inner classes");
		Outer5 o5 = new Outer5();
		o5.get(10);
		Outer5.Inner2  i5 = o5. new Inner2();
		i5.Square();
		i5.cube();
	}
}
